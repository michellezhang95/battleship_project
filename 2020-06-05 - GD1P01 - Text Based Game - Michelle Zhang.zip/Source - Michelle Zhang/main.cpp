﻿//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2020 Media Design School 
// 
// File Name     : main.cpp
// Description  : main function of the battleships project
// Author          : Michelle Zhang BSE20021
// E-Mail           : Michelle.Zha9048@mediadesign.school.nz
//
#include <iostream>
#include <windows.h>
#include <string>
#include "gameBoard.h"
#include "Game.h"
#include <time.h>


using namespace std;

//keep it simple and clean for main function
int main() {
	srand(time(NULL));
	Game game; // TF: Class
	if (game.start()) { // if restarting game create new game object to avoid using the same memory references
		Game *game = new Game(); // TF: Class Instance
		game->start();
	}

	int iTemp;
	cin >> iTemp;
	return 0;
}



	

