//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2020 Media Design School 
// 
// File Name     : Game.cpp
// Description  : Game source code which holds logic that acts as game controller 
// Author          : Michelle Zhang BSE20021
// E-Mail           : Michelle.Zha9048@mediadesign.school.nz
//
#include "Game.h"
#include "gameBoard.h"
#include "Ship.h"
#include <windows.h>
#include <iostream>
#include <conio.h>
#include <time.h>

HWND console = GetConsoleWindow();
RECT r;
COORD coord;
HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

Game::Game() //TF: Constructor
{
	isManual = false;
}

Game::~Game()
{
}

bool Game::start()
{
	GetWindowRect(console, &r);
	MoveWindow(console, r.left, r.top, 1000, 800, TRUE);
	//create game objects
	Ship air_carrier('A', 5, 1);
	Ship battleship('B', 4, 2);
	Ship destroyer('D', 3, 3);
	Ship submarine('S', 3, 4);
	Ship patrol_boat('P', 2,5);
	arr_ships[0] = air_carrier;
	arr_ships[1] = battleship;
	arr_ships[2] = destroyer;
	arr_ships[3] = submarine;
	arr_ships[4] = patrol_boat;
	Ship e_air_carrier('A', 5, 1);
	Ship e_battleship('B', 4, 2);
	Ship e_destroyer('D', 3, 3);
	Ship e_submarine('S', 3, 4);
	Ship e_patrol_boat('P', 2, 5);
	
	gameBoard playerBoard(false);
	gameBoard enemyBoard(true);
	attacked.push_back(std::make_pair(0, 0));
	enemyBoard.isAI = true;
	std::cout << "LOADING...PLEASE WAIT";
	playerBoard.addShipToBoard(air_carrier, battleship, destroyer, submarine, patrol_boat);
	GotoXY(0, 0);
	displayConsCursor(false);
	std::cout << "LOADING...";
	Sleep(1000);
	enemyBoard.addShipToBoard(e_air_carrier, e_battleship, e_destroyer, e_submarine, e_patrol_boat);
//	
	Sleep(2000);
	system("cls");
	std::cout << "Battleships    - GD1P01 Final Project Submission - Michelle Zhang BSE20021" << std::endl;
	std::cout << "1. Normal Mode" << std::endl;
	std::cout << "2. Debug Mode" << std::endl;
	std::cout << "3. Exit" << endl;
	std::cout << "To select your mode, press 1 or 2. To Exit press 3 (any other inputs will trigger normal play mode): ";
	displayConsCursor(true);
	char input;
	input = _getch();
	if (input == '3') {
		exit(0);
	}
	if (input == '2') gameMode = 2;
		system("cls");
		playerBoard.initialise_draw();
		playerBoard.draw(1,enemy_attacked);
		std::cout << endl << endl;
//
		srand((unsigned int)time(NULL));
		enemyBoard.initialise_draw();
		enemyBoard.draw(attacked, gameMode);
		GotoXY(20, 0);
		std::cout << "Your Board                                     Enemy Board";
//		
		if (chooseManual()) {	
			playerBoard.coordVec.clear();
			playerBoard.clearBoard();
			updateGame(&playerBoard, enemyBoard, attacked);
			placeShip(arr_ships, &playerBoard, enemyBoard);
			
			generateTurnOrder(&playerBoard, enemyBoard);
			
		}
		else {
			generateTurnOrder(&playerBoard, enemyBoard);
		}
		
		if (playerWin) {
			GotoXY(20, 25);
			std::cout << "You win!";
		}
		else if (computerWin) {
			GotoXY(20, 25);
			std::cout << "Computer wins!";
		}
		std::cout << "Press P to play again or press E to exit game";
		char end;
		end = _getch();
		if (end == 'p') {
			system("cls");
			playerBoard.coordVec.clear();
			playerBoard.randomGenList.clear();
			enemyBoard.coordVec.clear();
			enemyBoard.randomGenList.clear();
			playerBoard.clearBoard();
			enemyBoard.clearBoard();
			std::cout << "Restarting...                                    ";
			Sleep(2000);
			return true;
		}
		else if (end == 'e') {
			exit(0);
		}
}
void Game::placeShip(Ship ship[5], gameBoard* playerBoard, gameBoard enemyBoard)
{
	int x_input = 0, y_input = 0;
	//int x, y;
	char hv;
	int z = 27;
	GotoXY(75, 25);
	std::cout << "Ships left to assign: ";
	for (int i = 0; i < 5; i++) { // TF: Iterativve structure, logical operators
		GotoXY(75, z);
		std::cout << arr_ships[i].name << "  "<<arr_ships[i].shipSize <<" spaces";
		z++;
	}
	playerBoard->randomGenList.clear();
	vector <pair<int, int>> manual;
	//playerBoard->coordVec.clear();
	for (int i = 0; i < 5; i++) {
		displayConsCursor(true);
		GotoXY(15, 30);
		std::cout << "Find a coordinate to place the head of the " << arr_ships[i].name << "  ";
		GotoXY(15, 31);
		std::cout << arr_ships[i].shipSize << " spaces";
		GotoXY(15, 32);
		std::cout << "Enter alphabetical coordinate (A-J):  ";
		x_input = getAlpha();
		GotoXY(15, 34);
		std::cout << "Enter numerical coordinate (1-9, press 0 for 10) :";
		y_input = getNum();
		std::cout << y_input;
		GotoXY(15, 36);
		hv = getHV();
		std::cout << hv;
		displayConsCursor(false);
		
		manual.push_back(std::make_pair(x_input, y_input));
		int orientation = 0;
		if (hv == 'v') {
			orientation = 1;
		}
		else if (hv == 'h') {
			orientation = 0;
		}
		if (i == 0) {
			if (playerBoard->isDuplicate(&playerBoard->coordVec, x_input, y_input)) {
				GotoXY(20, 38);
				std::cout << "This is an invalid location. Please select another spot.";
				
				Sleep(1500);
				system("cls");
				updateGame(playerBoard, enemyBoard, attacked);
				i--;
				continue;

			}
			else {
				if (checkBoundary(arr_ships[i], x_input, y_input, orientation)) {
					addManual(arr_ships[i], playerBoard, x_input, y_input, hv);
					updateGame(playerBoard, enemyBoard, attacked);
				}
				else {
					GotoXY(20, 38);
					if (i > 0) {
						playerBoard->coordVec.erase(playerBoard->coordVec.begin(), playerBoard->coordVec.begin() + arr_ships[i].shipSize);
					}
					std::cout << "This position is out of bounds. Please select another spot.";
					Sleep(1500);
					system("cls");
					updateGame(playerBoard, enemyBoard, attacked);
					i--;
					continue;
				}
			}
		}
		else {
			//validate
			playerBoard->gameMode = gameMode;
			if (playerBoard->validateCoord(x_input, y_input, &arr_ships[i], orientation, 0)) {
				if (checkBoundary(arr_ships[i], x_input, y_input, orientation)) {
					addManual(arr_ships[i], playerBoard, x_input, y_input, hv);
					updateGame(playerBoard, enemyBoard, attacked);
				}
				else {
					GotoXY(20, 38);
					if (arr_ships[i].shipSize == 4) playerBoard->randomGenList.erase(playerBoard->randomGenList.end() - 5, playerBoard->randomGenList.end());
					if (arr_ships[i].shipSize == 3) playerBoard->randomGenList.erase(playerBoard->randomGenList.end() - 4, playerBoard->randomGenList.end());
					
					std::cout << "This position is out of bounds. Please select another spot.";
					Sleep(1500);
					system("cls");
					updateGame(playerBoard, enemyBoard, attacked);
					i--;
					continue;
				}
			}
			else {
				std::cout << "                          ";
				GotoXY(20, 38);
				std::cout << "There is already something here, please choose a new coordinate                        ";
				Sleep(1500);
				system("cls");
				updateGame(playerBoard, enemyBoard, attacked);
				i--;
				continue;
			}
		}
		}
	
}

void Game::addManual(Ship ship, gameBoard* gb, int x, int y, char hv)
{
	gb->addManual(ship, x, y, hv);
}

bool Game::checkBoundary(Ship ship, int x, int y, int hv)
{
	if (ship.shipSize == 5) {
		if (hv == 0) {
			if (y > 6) {
				return false;
			}
		}
		else if (hv == 1) {
			if (x > 6) {
				return false;
			}
		}
	}
	else if (ship.shipSize == 4) {
		if (hv == 0) {
			if (y > 7) {
				return false;
			}
		}
		else if (hv == 1) {
			if (x > 7) {
				return false;
			}
		}
	}
	else if (ship.shipSize == 3) {
		if (hv == 0) {
			if (y > 8) {
				return false;
			}
		}
		else if (hv == 1) {
			if (x > 8) {
				return false;
			}
		}
	}
	else if (ship.shipSize == 2) {
		if (hv == 0) {
			if (y > 8) {
				return false;
			}
		}
		else if (hv == 1) {
			if (x > 8) {
				return false;
			}
		}
	}
	return true;
}

string Game::markSunk(string s, bool isEnemy)
{
	std::string message;
	if (isEnemy) { // attack by enemy
		if (s == "A") {
			--a_segs;
			message = "Your air carrier has been hit!";
			return message;
		}
		else if (s == "B") {
			--b_segs;
			message = "Your battleship has been hit!";
			return message;
		}
		else if (s == "D") {
			--d_segs;
			message = "Your destroyer has been hit!";
			return message;
		}
		else if (s == "P") {
			--p_segs;
			message = "Your patrol boat has been hit!";
			return message;
		}
		else if (s == "S") {
			--s_segs;
			message = "Your submarine has been hit!";
			return message;
		}
	}
	else { // attack by player
		if (s == "A") {
			--ea_segs;
			message = "Enemy air carrier has been hit!";
			return message;
		}
		else if (s == "B") {
			--eb_segs;
			message = "Enemy battleship has been hit!";
			return message;
		}
		else if (s == "D") {
			--ed_segs;
			message = "Enemy destroyer has been hit!";
			return message;
		}
		else if (s == "P") {
			--ep_segs;
			message = "Enemy patrol boat has been hit!";
			return message;
		}
		else if (s == "S") {
			--es_segs;
			message = "Enemy submarine has been hit!";
			return message;
		}
	}
}

bool Game::sanitiseX(char x)
{
	if (x < 'a' || x > 'j') {
		std::cout << "Sorry, invalid value. Try again";
		Sleep(1000);
		std::cin.clear();
		std::cout << '\r';
		return false;
	}
	else {
		return true;
	}
}

bool Game::sanitiseY( int n)
{
	
	if (!isdigit(n)) {
		std::cout << "Sorry, invalid value. Try again";
		std::cout << '\r';
		Sleep(1000);
		cin.clear();
		return false;
	}
	else {
		return true;
	}
}

int Game::getAlpha()
{
	
	char x = _getch();
	if (!sanitiseX(x)) {
		cin.clear();
		std::cout << "                                                                                                           ";
		std::cout << '\r';
		GotoXY(15, 32);
		std::cout << "Enter alphabetical coordinate (A-J):  ";
		getAlpha();
	}
	else {
		//std::string s(1, x);
		char upper = x - 32;
		std::cout << upper;
		int x_input = (int)(x % 97+1);
		return x_input;
	}
	
}

int Game::getNum()
{
	
	char y = _getch();
	if (!sanitiseY(y)) {
		
		cin.clear();
		std::cout << "                                                                                                           ";
		std::cout << '\r';
		GotoXY(15, 34);
		std::cout << "Enter numerical coordinate (1-9, press 0 for 10) :";
		getNum();
	}
	else {
		int y_input = (int)(y % 49+1);
		return y_input;
	}
	
}

char Game::getHV()
{
	GotoXY(15, 36);
	std::cout << "Vertical or Horizontal placement?(Press H or V): ";
	char in = _getch();
	if (in != 'h' && in != 'v') {
		std::cout << "Invalid input. Please try again.";
		std::cout << '\r';
		std::cout << "                                                                                                           ";
		cin.clear();
		getHV();
	}
	else {
		return in;
	}
		
}

bool Game::checkDuplicate(int x, int y)
{
	for (unsigned int i = 0; i < attacked.size(); i++) {
		if (attacked.at(i) == std::make_pair(x, y)) {
			std::cout << "This is coordinate has already been entered. Try again";
			Sleep(1000);
			std::cout << '\r';
			std::cout << "															         ";
			return true;
		}
	}
	return false;
}
	



void Game::GotoXY(int x, int y)
{
	COORD point;
	point.X = x;
	point.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
}

void Game::generateTurnOrder(gameBoard *playerBoard, gameBoard enemyBoard) // TF: Pass by reference
{
	
	GotoXY(20, 30);
	std::cout << "Generating turn order...           ";
	Sleep(1500);
	
	srand((unsigned int)time(NULL));
	int gen_turn = (rand() % 2) + 1; // TF: Pseudorandom number generator
	Sleep(500);
	if (gen_turn == 1) { // player goest first
		playerBoard->isTurn = true;
		enemyBoard.isTurn = false;
		GotoXY(20, 36);
		std::cout << "You go first!";
	}
	else { // CPU goes first
		enemyBoard.isTurn = true;
		playerBoard->isTurn = false;
		GotoXY(20, 36);
		std::cout << "CPU goes first!";
	}
	Sleep(2000);
	play(playerBoard, enemyBoard);
}

bool Game::chooseManual()
{
	GotoXY(20, 25);
	std::cout << "Press M to manually edit ship placements or press Q to play now";
	char input;
	input = _getch();
	if (input == 'q') {
		isManual = false;
		return false;
	} if (input == 'm') {
		isManual = true;
		return true;
	}                       
}

void Game::play(gameBoard *playerBoard, gameBoard enemyBoard)
{
	//updateGame(playerBoard, enemyBoard);
	while (!win) { //while win condition has not been reached by either party	
		if (playerBoard->isTurn) {
			if (attack(false, playerBoard, enemyBoard,attacked)) {
				if (player_segs == 0) return;
				play(playerBoard, enemyBoard,attacked);
			}
			else {
				enemyBoard.isTurn = true;
				playerBoard->isTurn = false;
				continue;
			}
		}
		else if (enemyBoard.isTurn) {
			if (attack(true, playerBoard, enemyBoard,attacked)) {
				if (computer_segs == 0) return;
				play(playerBoard, enemyBoard);
			}
			else {
				playerBoard->isTurn = true;
				enemyBoard.isTurn = false;
				continue;
			}	
		}
	}
}

void Game::play(gameBoard* playerBoard, gameBoard enemyBoard, vector <pair<int,int>> attacked)
{
	updateGame(playerBoard, enemyBoard,attacked);
	//attacked.clear();
	while (!win) { //while win condition has not been reached by either party
		if (playerBoard->isTurn) {
			if (attack(false, playerBoard, enemyBoard, attacked)) {
				if (player_segs == 0) return;
				continue;
			}
			else {
				enemyBoard.isTurn = true;
				playerBoard->isTurn = false;
				continue;
			}
		}
		else if (enemyBoard.isTurn) {
			if (attack(true, playerBoard, enemyBoard, attacked)) {
				if (computer_segs == 0) return;
				continue;
			}
			else {
				playerBoard->isTurn = true;
				enemyBoard.isTurn = false;
				continue;
			}
		}
	}
}

bool Game::attack(bool isAI, gameBoard *pb, gameBoard eb, vector<pair<int, int>> a_vec)
{
	int x_input, y_input;
	char y;
	srand((unsigned int)time(NULL));
	updateGame(pb, eb,attacked);
	if (isAI) {
		x_input = rand() % 10 + 1;
		Sleep(500);
		y_input = rand() % 10 + 1;
		GotoXY(20, 30);
		std::cout << "CPU's turn - Attack Phase       ";
		GotoXY(20, 32);
		std::cout << "CPU guessed: (" << pb->board[x_input][0] << ", " << y_input << ")";

		if (pb->board[x_input][y_input] == "o") {
			pb->board[x_input][y_input] = "X";
			GotoXY(20, 35);
			std::cout << "MISS";
			enemy_attacked.push_back(std::make_pair(x_input, y_input));
			Sleep(2500);
			return false;
		}
		else if (pb->board[x_input][y_input] != "o") {
			GotoXY(20, 35);
			std::cout << "HIT";
			std::cout << endl;
			GotoXY(34, 35);
			std::cout<<markSunk(pb->board[x_input][y_input], true);
			computer_segs--;
			enemy_attacked.push_back(std::make_pair(x_input, y_input));
			Sleep(1000);
			if (computer_segs == 0) {
				computerWin = true;
				win = true;
				return true;
			}
			Sleep(2000);
			return true;
		}
	}
	else {
		GotoXY(20,30);
		std::cout << "Your turn - Attack Phase      ";
		GotoXY(20, 32);
		std::cout << "Enter alphabetical coordinate (A-J): ";
		//
		x_input = getAlpha();
		std::cout << x_input;
		GotoXY(20, 33);
		std::cout << "Enter numerical coordinate (press 0 for 10) : ";
		y = getNum();
		if (y == '0') {
			y_input = 10;
		}
		else {
			y_input = (int)(y % 49);
		}
		GotoXY(20, 35);
		if (checkDuplicate(x_input, y_input)) {
			system("cls");
			cin.clear();
			attack(false, pb, eb, attacked);
		}
		else {
			std::cout << "You entered (" << x_input << ", " << y_input << ")";
			GotoXY(20, 37);
			std::cout << "Attacking...";
			Sleep(1000);
		}
		
		
		if (eb.board[x_input][y_input] == "o") {
			GotoXY(34, 37);
			std::cout << "MISS";
			std::cout << '\r';
			std::cout << "																					";
			attacked.push_back(std::make_pair(x_input, y_input));
			Sleep(1000);
			return false;
		}
		else if (eb.board[x_input][y_input] != "o") {
			GotoXY(34, 37);
			std::cout << "HIT";
			player_segs--;
			std::cout << endl;
			GotoXY(34, 37);
			std::cout << markSunk(eb.board[x_input][y_input], false);
			attacked.push_back(std::make_pair(x_input, y_input));
			GotoXY(34, 39);
			std::cout << "Ship locations left: " << player_segs;
			Sleep(1000);
			if (player_segs == 0) {
				playerWin = true;
				win = true;
				return true;
			}
			Sleep(1000);
			return true;
		}
	}
	
}



void Game::updateGame(gameBoard *playerBoard, gameBoard enemyBoard)
{
	system("cls");
	GotoXY(0, 0);
	//std::cout << "		Player Board " << endl << endl;
	displayConsCursor(true);
	playerBoard->draw(isManual , enemy_attacked);
	GotoXY(30, 0);
	//std::cout << "               Enemy Board" << endl <<endl;
	enemyBoard.draw(attacked,gameMode);
	GotoXY(20, 0);
	std::cout << "Your Board                                     Enemy Board";
	GotoXY(0, 0);
}

void Game::updateGame(gameBoard *playerBoard, gameBoard enemyBoard, vector<pair<int, int>> attacked)
{
	system("cls");
	GotoXY(0, 0);
	playerBoard->draw(isManual, enemy_attacked);
	GotoXY(30, 0);
	enemyBoard.draw(attacked,gameMode);
	GotoXY(20, 0);
	std::cout << "Your Board                                     Enemy Board";
	//GotoXY(0, 0);
}

void Game::displayConsCursor(bool show)
{
	CONSOLE_CURSOR_INFO cursorInfo;
	GetConsoleCursorInfo(h, &cursorInfo);
	cursorInfo.bVisible = show;
	SetConsoleCursorInfo(h, &cursorInfo);
}


