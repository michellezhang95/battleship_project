#include "Ship.h"
#include <iostream>
#include <string>

//Ship::Ship()
//{
//}

Ship::Ship(char value, int s, int t) {
	//create array based on parameters the ship object was created with
	val = value;
	type = t;
	ship_arr = new char[s];
	for (int m = 0; m < s; m++) {
		ship_arr[m] = value;
		//std::cout<< ship_arr[m]; //print to check what is populating the array
	}
	shipSize = s;
	switch (t) {
	case 1:
		name = "air carrier";
		break;
	case 2:
		name = "battleship";
		break;
	case 3:
		name = "destroyer";
		break;
	case 4: 
		name = "submarine";
		break;
	case 5:
		name = "patrol boat";
		break;
	default:
		break;
	}
}
Ship::Ship()
{

}

Ship::~Ship()
{

}

int Ship::returnSize()
{
	return shipSize;
}



