//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2020 Media Design School 
// 
// File Name     : gameBoard.h
// Description  : gameBoard header file
// Author          : Michelle Zhang BSE20021
// E-Mail           : Michelle.Zha9048@mediadesign.school.nz
//
#pragma once
#include <string>
#include "Ship.h"
#include <vector> 
using namespace std;
//declarations for gameBoard class
const int max_ships = 5;
const int max_grid = 10;
class gameBoard
{
private:
	
public:
	gameBoard();
	gameBoard(bool = false); // TF: Default parameter
	~gameBoard();
	void initialise_draw();
	void clearBoard();
	void randomGen(Ship* []);
	void draw(bool , vector<pair<int, int>>);
	void draw(vector<pair<int, int>>, char);
	bool isDuplicate(vector<pair<int, int>>*,int, int);
	bool isDuplicate(vector<int,int>);
	bool validateCoord(int, int, Ship*,int, int);

	int horizontalVertical();
	//bool checkRadius(int x_coord, int y_coord, Ship* ship, string(&b)[][10]);
	bool checkRadius(int x, int y);	

	void GotoXY(int, int);
	int getNumOfShips();
	void addShipToBoard(Ship a, Ship b,Ship c,Ship d,Ship e); //there is probably a better way to do this lol
	void updatePlayerBoard(Ship , int , int);
	bool validateManual(Ship, int, int,char);
	void addManual(Ship, int, int, char);


	//
	Ship* a_ships[max_ships]; //arr to hold list of ships on the board
	int numOfShips =0;
	int numOfSegments =0;
	int gameMode;
	vector < pair <int, int> > coordVec; //vector to hold pairs of coordinates already entered
	vector < pair <int, int> > randList;
	vector <pair <int, int>> randomGenList;
	vector <pair <int, int>> debugList;
	std::string board[12][12];
	bool isAI = false;
	bool isTurn =false;
	
	
};



