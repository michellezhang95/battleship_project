//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2020 Media Design School 
// 
// File Name     : gameBoard.cpp
// Description  : gameBoard source code which holds all gameBoard logic
// Author          : Michelle Zhang BSE20021
// E-Mail           : Michelle.Zha9048@mediadesign.school.nz
//
#include "gameBoard.h"
#include "Ship.h"
#include <iostream>
#include <string>
#include <time.h>
#include <typeinfo>
#include <cstdlib>
#include <stdio.h>
#include <Windows.h>
#include <utility>
#include <conio.h>
#include <algorithm>
#include "Game.h"
using namespace std;

string board[12][12];
HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
gameBoard::gameBoard()
{

	numOfShips = 0;
	numOfSegments = 0;
	isAI = false;
}

gameBoard::gameBoard(bool isAI)
{
	isAI = true;

	//board[12][12];
}

gameBoard::~gameBoard()
{
}

void gameBoard::initialise_draw() {
	//system("cls");
		cout << endl<<endl ;
		for (int i = 0; i < 11; i++) {
			//for each column
			for (int j = 0; j < 11; j++) {
				if (i == 0) {
					switch (j) {
					case 1:
						board[i][j] = "1";
						break;
					case 2:
						board[i][j] = "2";
						break;
					case 3:
						board[i][j] = "3";
						break;
					case 4:
						board[i][j] = "4";
						break;
					case 5:
						board[i][j] = "5";
						break;
					case 6:
						board[i][j] = "6";
						break;
					case 7:
						board[i][j] = "7";
						break;
					case 8:
						board[i][j] = "8";
						break;
					case 9:
						board[i][j] = "9";
						break;
					case 10:
						board[i][j] = "10";
						break;
					default:
						break;
					}
				}
				else {
					if (j == 0) {
						switch (i) {
						case 1:
							board[i][j] = "A";
							break;
						case 2:
							board[i][j] = "B";
							break;
						case 3:
							board[i][j] = "C";
							break;
						case 4:
							board[i][j] = "D";
							break;
						case 5:
							board[i][j] = "E";
							break;
						case 6:
							board[i][j] = "F";
							break;
						case 7:
							board[i][j] = "G";
							break;
						case 8:
							board[i][j] = "H";
							break;
						case 9:
							board[i][j] = "I";
							break;
						case 10:
							board[i][j] = "J";
							break;
						default:
							break;
						}
					}
					else {
						if (board[i][j] == "") {
							board[i][j] = "o";
						}
					}
				}
			}
		}
}// end of initialise_draw();


//clear board if player wants to manually place ships
void gameBoard::clearBoard()
{
	for (int i = 1; i < 11; i++) {
		for (int j = 1; j < 12; j++) {
			if (board[i][j] != "o") {
				board[i][j] = "o";
			}
		}
	}
}

//generate valid coordinates for each ship type
void gameBoard::randomGen(Ship* m[])
{
	int x = 65; int y = 5;
	bool duplicate = true;
	Sleep(200);
	srand((unsigned int)time(NULL));
	int x_coord, y_coord;
	int x_coord2, y_coord2;
	int orientation;
	int shifted = 0;
	//while there are still ships left to be placed
		//for each ship type
	for (int i = 0; i < getNumOfShips(); i++) {
		// while there are still segments of the ship segments left
		numOfSegments = m[i]->shipSize;
		//numOfSegments = (int) (a).shipSize;
		orientation = horizontalVertical();
		x_coord = 1+ rand() % (10 - 1 + 1);
		y_coord = 1+rand() % (10 - 1 + 1);
		x_coord2 = x_coord;
		y_coord2 = y_coord;
		int tailhead = 0; // 1 = tail 0 = head
		Sleep(100);
		if (validateCoord(x_coord2, y_coord2, m[i], orientation, tailhead)) {
			Sleep(100);
			x_coord = x_coord2;
			y_coord = y_coord2;
			while (numOfSegments > 0) {
				//validate placement
				board[x_coord][y_coord] = m[i]->val;
				std::cout << endl;
				debugList.push_back(std::make_pair(x_coord, y_coord));
				std::cout << "Ship " << m[i]->name << "  (" << x_coord << ", " << y_coord << ")";
				if (orientation) { // if vertical
					if (x_coord < 10) {
						x_coord++;
						numOfSegments--;
						continue;
					}
					if (x_coord == 10) {
						int minus = m[i]->shipSize - 1;
						x_coord = x_coord - minus;
					}
				}
				else {
					if (y_coord < 10) {
						y_coord++;
						numOfSegments--;
						continue;
					}
					if (y_coord == 10) {
						int minus = m[i]->shipSize - 1;
						y_coord = y_coord - minus;
					}
				}
				numOfSegments--;
			}
		}
		else {
				x_coord = 1 + rand() % (10 - 1 + 1);
				y_coord = 1 + rand() % (10 - 1 + 1);
				i--;
		}	
	}
	randomGenList.clear();
}

void gameBoard::GotoXY(int x, int y)
{
	COORD point;
	point.X = x;
	point.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
}

void gameBoard::draw(bool placeholder, vector<pair<int,int>> enemy_attacked)
{
	GotoXY(0, 2);
	
	int y_pos = 2;
		for (int i = 0; i < 11; i++) {
			if (i == 0) std::cout << "    ";
			for (int j = 0; j < 12; j++) {
				if (j == 11) {
					y_pos += 2;
					GotoXY(0, y_pos);
				}
				
				else {
					if (placeholder == true || placeholder == false) {
						if (i != 0 && j != 0) {
							if (enemy_attacked.size() == 0) {
								if (board[i][j] != "o") {
									SetConsoleTextAttribute(hStdOut, 6);
								}
							}
							else {
								for (unsigned int n = 0; n < enemy_attacked.size(); n++) {
									if (std::make_pair(i, j) == enemy_attacked.at(n)) {
										if (board[i][j] != "o") {
											SetConsoleTextAttribute(hStdOut, 4);
											std::cout << board[i][j];
											std::cout << "\b";
											break;
										}
										else {
											SetConsoleTextAttribute(hStdOut, 2);//green
										}
									}
									else {
										if (board[i][j] != "o") {
											SetConsoleTextAttribute(hStdOut, 6);
										}
									}
								}
							}
						}
					}
					else {
						std::cout << board[i][j];
					}

					std::cout << board[i][j];
				}
				std::cout << "   ";
				SetConsoleTextAttribute(hStdOut, 15);
			}
		}
}

void gameBoard::draw( vector<pair<int, int>> attacked, char gameMode)
{
	GotoXY(55, 2);
	int y_pos = 2;
	int already = 0;
	for (int i = 0; i < 11; i++) {
		if (i == 0) std::cout << "    ";
		for (int j = 0; j < 12; j++) {
			if (j == 11) {
				/*std::cout << std::endl << std::endl;*/
				y_pos += 2;
				GotoXY(55, y_pos);
			}
			else {
				if (i != 0 && j != 0) { // if the element is not a grid label
					for (unsigned int z = 0; z < attacked.size(); z++) {
							//anything before the if loop will make the grid be drawn multiple times with an offset
							if (attacked.at(z) == std::make_pair(i, j)) {
								if (attacked.size() > 1 && z != 0) {
									std::cout << "\b\b ";
								}
								if (board[i][j] == "o") {
									SetConsoleTextAttribute(hStdOut, 4);//red
									std::cout << "o";
								}
								else {
									SetConsoleTextAttribute(hStdOut, 3);
									std::cout << board[i][j];
									
									already = 1;
								}
							}
							else {
								if (already != 1) {
									std::cout << "o";
									already = 1;
								}
								else {
									continue;
								}
								//printing anything here will result in wrong display
							}
					}
					already = 0;
				}
				else if (i == 0 || j ==0)  { // if the element is a grid label
					std::cout << board[i][j];
				}
			}
			SetConsoleTextAttribute(hStdOut, 15);
			std::cout << "   ";
		}
	}
	if ((int)gameMode == 2) {
		GotoXY(105, 5);
		int j = 5;
		string output;
		for (unsigned int i = 0; i < debugList.size(); i++) {
			if (debugList.at(i).first == 1) output = "A";
			if (debugList.at(i).first == 2) output = "B";
			if (debugList.at(i).first == 3) output = "C";
			if (debugList.at(i).first == 4) output = "D";
			if (debugList.at(i).first == 5) output = "E";
			if (debugList.at(i).first == 6) output = "F";
			if (debugList.at(i).first == 7) output = "G"; 
			if (debugList.at(i).first == 8) output = "H";
			if (debugList.at(i).first == 9) output = "I";
			if (debugList.at(i).first == 10) output = "J";
			std::cout << "Coord (" << output << ", " << debugList.at(i).second << ")";
			++j;
			GotoXY(105, j);
		}
	}
	
}
	
//checks if coordinates already have been used/entered
bool gameBoard::isDuplicate(vector<pair<int, int>> *list, int first, int second)
{
	int isDupe = 0;
	if (coordVec.size() == 0) {
		coordVec.push_back(std::make_pair(first, second));
		return false;
	}
	else {
		for (unsigned int i = 0; i < coordVec.size(); i++) {
			if (coordVec.at(i) == std::make_pair(first, second)) {
				isDupe = 1;
			}
		}
		if (isDupe == 0) { //if coordinate doesnt already exist, add to coordVec data structure
			coordVec.push_back(std::make_pair(first, second));
			return false;
		}
		else if (isDupe) {
			return true;
		}
	}
}

bool gameBoard::validateCoord(int x_coord, int y_coord, Ship* ship, int hv, int tailhead)
{
	int invalid = 0;
	int x, y;
	x = x_coord;
	y = y_coord;
	vector<pair<int, int>> compare;
	for (int i = 0; i < ship->shipSize; i++) { //add ships to this local vector
		if (i == 0) compare.push_back(std::make_pair(x, y));
		if (i > 0) {
			if (hv == 0) { //horizontal
				//change in y
				if (y == 10) {
					y -= ship->shipSize-1; 
				}
				else {
					y++;
				}
				compare.push_back(std::make_pair(x, y));
			}
			else {
				if (x == 10) {
					x -= ship->shipSize-1;
				}
				else {
					x++;
				}
				compare.push_back(std::make_pair(x, y));
			}
		}
	}
	for (unsigned int i = 0; i < compare.size(); i++) { // check if forecasted coordinates would conflict with any existing coordinate in vector list
		for (unsigned int j = 0; j < randomGenList.size(); j++) {
			if (compare.at(i) == randomGenList.at(j)) {
				//std::cout << "DUPLICATE    (" << compare.at(i).first << ", " << compare.at(i).second << ")  in list[" << j << "]";
				Sleep(200);
				x_coord = 1 + rand() % (10 - 1 + 1);
				y_coord = 1 + rand() % (10 - 1 + 1);
				return false;
			}
		}
	}
	
	for (unsigned int i = 0; i < compare.size(); i++) { //if we find no conflicts
		x = compare.at(i).first;
		y = compare.at(i).second;
		if (hv == 0) { //horizontal
			randomGenList.push_back(std::make_pair(x - 1, y));
			randomGenList.push_back(std::make_pair(x + 1, y));
			if (tailhead == 0) { //head
				randomGenList.push_back(std::make_pair(x, y - 1));
			}
			if (i == ship->shipSize - 1) {
				randomGenList.push_back(std::make_pair(x, y + 1));
			}		
		}
		else if (hv == 0) {
			randomGenList.push_back(std::make_pair(x, y + 1));
			randomGenList.push_back(std::make_pair(x, y - 1));
			if (tailhead == 0) {
				randomGenList.push_back(std::make_pair(x - 1, y));
			}
			if (i == ship->shipSize - 1) {
				randomGenList.push_back(std::make_pair(x + 1, y));
			}	
		}
		
		randomGenList.push_back(std::make_pair(x, y));
	}
	return true;
}
	
int gameBoard::horizontalVertical()
{
	int hv = (rand() % 2 +1);
	if (hv == 1) { return 1; //vertical 1
	}
	else {
		return 0; //horizontal
	}
}

bool gameBoard::checkRadius(int x, int y)
{
	if (board[x + 1][y] != "o") {return false;}
	else if (board[x - 1][y] != "o") {return false;}
	else if (board[x][y - 1] != "o") {return false;}
	else if (board[x][y + 1] != "o") {return false;}
	else if (board[x-1][y + 1] != "o") { return false; }
	else if (board[x+1][y + 1] != "o") { return false; }
	else if (board[x-1][y - 1] != "o") { return false; }
	else if (board[x+1][y - 1] != "o") { return false; }
	else {
		return true;
	}
}

int gameBoard::getNumOfShips() 
{
	numOfShips = sizeof(a_ships)/sizeof(*a_ships);
	//std::cout << numOfShips;
	return numOfShips;
}

//adds all of the ship objects to individual board to keep track of ships
void gameBoard::addShipToBoard(Ship a, Ship b, Ship c, Ship d, Ship e)
{
	a_ships[0] = &a; //TF: Array
	a_ships[1] = &b;
	a_ships[2] = &c;
	a_ships[3] = &d;
	a_ships[4] = &e;
	
	numOfShips = getNumOfShips();
	randomGen(a_ships);
	initialise_draw();	
}

void gameBoard::addManual(Ship ship, int x, int y, char hv)
{
	for (int i = 0; i < ship.shipSize; i++) {
		if (hv == 'h') {
			if (i == 0) {
				
				randomGenList.push_back(std::make_pair(x, y));
				board[x][y] = ship.val;
				y++;
				continue;
			}
			else {
				
				randomGenList.push_back(std::make_pair(x, y));
				board[x][y] = ship.val;
				y++;
			}
			
		}
		else if (hv == 'v') {
			if (i == 0) {
				
				randomGenList.push_back(std::make_pair(x, y));
				board[x][y] = ship.val;
				x++;
				continue;
			}
			else {
			
				randomGenList.push_back(std::make_pair(x, y));
				board[x][y] = ship.val;
				x++;
			}
		}
	}
}
