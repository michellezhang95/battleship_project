#pragma once
#include "gameBoard.h"
#include "Game.h"
class Player {
public:
	Player();
	~Player();
	void inputCoords(int x, char y);
	void GotoXY(int x, int y);
	bool attack(bool , gameBoard );
	void placeShips(int x, char y);
	int isTurn;
	int segs_left = 17;
};

