#include "Player.h"
#include "Game.h"
#include "gameBoard.h"
#include <iostream>
#include <conio.h>
#include <Windows.h>

Player::Player()
{
	
}

Player::~Player()
{
}

void Player::inputCoords(int x, char y)
{
}
void Player::GotoXY(int x, int y)
{
	COORD point;
	point.X = x;
	point.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
}
bool Player::attack(bool isAI, gameBoard enemyBoard)
{
	int x_input, y_input;
	char x, y;
	std::pair <int, int> coordinates;

	if (isAI) {

	}
	else {
		GotoXY(50, 5);
		std::cout << "Your turn - Attack Phase      ";
		GotoXY(50, 6);
		std::cout << "Enter alphabetical coordinate: ";
		//
		x = _getch();
		x_input = (int)((x) % 97) + 1;

		std::cout << x;
		GotoXY(50, 7);
		std::cout << "Enter numerical coordinate (press 0 for 10) : ";
		y = _getch();
		if (y == '0') {
			y_input = 10;
		}
		else {
			y_input = (int)(y % 49 + 1);
		}

		GotoXY(50, 8);
		std::cout << "You entered (" << x << ", " << y_input << ")";
		coordinates = std::make_pair(x_input, y_input);

		GotoXY(50, 10);
		std::cout << "Attacking...";
		std::cout << enemyBoard.board[2][1];
		Sleep(1000);
		GotoXY(50, 11);
		std::cout << enemyBoard.board[x_input][y_input];
		if (enemyBoard.board[x_input][y_input] == "o") {
			GotoXY(50, 11);
			std::cout << "MISS";

			Sleep(2000);
			return true;

		}
		else if (enemyBoard.board[x_input][y_input] != "o") {
			GotoXY(50, 11);
			std::cout << "HIT";
			segs_left--;
			Sleep(2000);
			return false;
		}


	}
}