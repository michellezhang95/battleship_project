//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2020 Media Design School 
// 
// File Name     : Ship.h
// Description  : header file of Ship Class
// Author          : Michelle Zhang BSE20021
// E-Mail           : Michelle.Zha9048@mediadesign.school.nz
//
#pragma once
#include <iostream>
#include <string>

class Ship
{
private:
	char* ship_arr; //TF:private access specifier
public:
	Ship(char, int,int);
	Ship();
	~Ship();
	int returnSize();
	
	std::string val;
	int type; // 1 = air carrier, 2  = battleship, 3 = destroyer, 4 = submarine, 5 = patrol boat
	bool sunk = false;
	bool afloat = true;
	// type;
	std::string name;
	int shipSize;



	


};

